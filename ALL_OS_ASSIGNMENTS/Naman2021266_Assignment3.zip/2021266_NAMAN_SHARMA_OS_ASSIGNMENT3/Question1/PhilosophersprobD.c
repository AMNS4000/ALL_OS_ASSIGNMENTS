#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
#include<semaphore.h>
#include<string.h>
typedef struct{
    int id;
    int loopcnt;
}id;
sem_t forks[5];
sem_t bowl;
int getleft(int p){
    return p;
}
int getright(int p){
    return (p+1)%5;
}
void think(int pid){
    printf("Philosopher %d has started to think \n", pid);
    sleep(1);
}
void getsaucebawl(int pid){
    sem_wait(&bowl);
    printf("Bowl given to Philosopher: %d\n", pid);
    sleep(1);
}
void eat(int pid){
    if (pid==4){
        sem_wait(&forks[getright(pid)]);
        sem_wait(&forks[getleft(pid)]);
        printf("Philosopher %d has started to eat \n", pid);
        sleep(1);
    }
    else{
        sem_wait(&forks[getleft(pid)]);
        sem_wait(&forks[getright(pid)]);
        printf("Philosopher %d has started to eat \n ",pid);
        sleep(1);
    }
    sem_post(&forks[getleft(pid)]);
    sem_post(&forks[getright(pid)]);
    sem_post(&bowl);
}
void *philosopher(void *arg){
    id *funcid= (id *)arg;
    int p= funcid->id;
    int j;
    while(1){
        think(p);
        getsaucebawl(p);
        eat(p);
    }
    return NULL;

}
int main(){
    pthread_t philosopherarr[5];
    for (int j=0; j<5; j++){
        sem_t fork;
        forks[j]=fork;
    }
    for (int h=0; h<5; h++){
        sem_init(&forks[h],0,1);
    }
    sem_init(&bowl,0,2);
    for (int i=0; i<5; i++){
        id* arg1= malloc(sizeof(id));
        arg1->id=i;
        pthread_create(&philosopherarr[i], NULL , philosopher, (void *)arg1);
    }
    for (int j=0; j<5; j++){
        pthread_join(philosopherarr[j], NULL);
    }
    return 0;
}