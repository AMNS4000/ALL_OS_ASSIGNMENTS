#include <stdio.h>
#include <stdlib.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <string.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

#define SHM_PATH "address"
#define SIZE 512

struct memRegion {
    char sendarr[15];
    char recvarr[15];
};

int main() {
  int indx = 0;
  int shm;
  if ((shm = shm_open(SHM_PATH, O_CREAT | O_RDWR, 666)) < 0) {
    return 0;
  }
  char* region = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm, 0);


  int indxf;
  while (1) {
    char ma[5];
    for (int i=0; i<5; i++) {
      char* recvString = (char *) region;
      region += strlen(recvString) + 1;
      char* token = strtok(recvString, " ");
      token = strtok(NULL, " ");
      strcpy(ma, token);
      printf("[CLIENT] Received String: %s, ID: %s\n", recvString, ma);
    }
    sprintf(region, "%s", ma);
    region += strlen(ma)+1;


    if (!strcmp(ma, "49")) {
      break;
    }
    indx += 5;
    sleep(1);
  }

  munmap(region, SIZE);
  close(shm);
  shm_unlink(SHM_PATH);
  
  return 0;
}