#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#include<dirent.h>
#include<errno.h>
#define MAX_B 1000
char *strdelch(char *str, char ch)
{
    char *curr= str;
    char *ta= str;
    while(*ta)
    {
        if(*ta== ch)
        {
            ta++;
        }
        else
        {
            *curr++ = *ta++;
        }
    }
    *curr= 0;
    return str;
}
void ls(char *d, int a, int r){
    struct dirent *d1;
    DIR *f=opendir(d);
    if (!f){
        if (errno = ENOENT){
            perror("Directory does not exist");
        }
        else{
            perror("Directory is not readable");
        }
        exit(0);
    }
    if (a==0 && r==0){
        while ((d1=readdir(f))!= NULL){
            if (!a && d1->d_name[0]=='.'){
                continue;
            }
            printf("%s ",d1->d_name);
        }
    }
    else if (a==1){
        while ((d1=readdir(f))!= NULL){
            if (!a && d1->d_name[0]=='.'){
                continue;
            }
            printf("%s ",d1->d_name);
        }
    }
    else if (r==1){
        int indx=0;
        char lsl[1000]=" ";
        while ((d1=readdir(f))!= NULL){
            if (!a && d1->d_name[0]=='.'){
                continue;
            }
            int u=0;
            indx++;
            strcat(lsl," ");
            strcat(lsl,d1->d_name);

        }
        int s;
        int e=strlen(lsl)-1;
        for (int g=strlen(lsl)-1; g>=0; g--){
            if (lsl[g]==' ' || g==0){
                if (g==0){
                    s=0;
                }
                else{
                    s=g+1;
                }
                for (int j=s; j<=e; j++){
                    printf("%c",lsl[j]);
                }
                e=g-1;
                printf(" ");
            }
        }
    }
}
int main(int argc, char *argv[]){
    printf(">");
    while (1){
        char t[1000];
	int buffsize=4096;
        char p[MAX_B];
        fgets(t,100,stdin);
	int z=strlen(t);
	t[z-1]='\0';
        char str1[100][100];
        int cnt=0;
        int en=0;
        for (int i=0; i<=strlen(t); i++){
            if (t[i]==' ' || t[i]=='\0'){
                str1[cnt][en]='\0';
                cnt++;
                en=0;
            }
            else{
                str1[cnt][en]=t[i];
                en++;
            }
        }
        if (strcmp(str1[0],"exit")==0){
            exit(1);
            break;
        }
        else{
            if (strcmp(str1[0],"pwd")==0 ||(strcmp(str1[0],"pwd") && strcmp(str1[1],"-L")==0) ||(strcmp(str1[0],"pwd") && strcmp(str1[1],"-P"))==0){ 
                char *h=getcwd(NULL,0);
                if (h==NULL){
                    perror("getcwd");
                }
                printf("Current working directory is: %s\n",h);
                free(h);
            }
            else if (strcmp(str1[0],"echo")==0){
                if (strcmp(str1[1],"*")!=0 && strcmp(str1[1],"-n")!=0){
                    for (int h=1; h<cnt; h++){
                        printf("%s ",str1[h]);
                    }
                }
                else if (strcmp(str1[1],"-n")==0){
                    int i=2;
                    for (int g=2; g<cnt; g++){
                        printf("%s ",strdelch(str1[g],'"'));
                    }
                }
                else if (strcmp(str1[1],"*")==0){
                    ls(".",0,0);
                }
            }
            else if (strcmp(str1[0],"cd")==0){
                if (strcmp(str1[1],"~")==0){
                    char *h=getcwd(NULL,0);
                    if (h==NULL){
                        perror("getcwd");
                    }
                    chdir(" ");
                    char *i=getcwd(NULL,0);
                    if (i==NULL){
                        perror("getcwd");
                    }
                    if (strcmp(h,i)==0){
                        printf("No such directory exists.Path Not found.");
                    }
                    else{
                        printf("Previous working directory is: %s\n",h);
                        free(h);
                        printf("Current working directory is: %s\n",i);
                        free(i);
                    }
                }
                else{
                    char *h=getcwd(NULL,0);
                    if (h==NULL){
                        perror("getcwd");
                    }
                    chdir(str1[1]);
                    char *i=getcwd(NULL,0);
                    if (i==NULL){
                        perror("getcwd");
                    }
                    if (strcmp(h,i)==0){
                        printf("No such directory exists.Path Not found.");
                    }
                    else{
                        printf("Previous working directory is: %s\n",h);
                        free(h);
                        printf("Current working directory is: %s\n",i);
                        free(i);
                    }
                }           
                
            }
            else if (strcmp(str1[0],"ls")==0){
                int rc=fork();
		if (rc==0){
			if (cnt==1){
				if (execl("./ls",NULL)==-1){
					printf("Failed");
				}
			}
			else if (cnt==2){
				if (execl("./ls",str1[1],NULL)==-1){
					}

			}
			else{
				printf("Invalid arguments");
				break;
			}
		}
		else if (rc>0){
			int wt;
			wait(&wt);
			continue;
			}
		}
	    else if (strcmp(str1[0],"rm")==0){
		int rc=fork();
		if (rc==0){
			if (cnt==2){
				if (execl("./rm",str1[1],NULL)==-1){}
				}
			else if (cnt==3){
				if (execl("./rm",str1[1],str1[2],NULL)==-1){}
				}
			
			else{
				printf("Invalid arguments");
				break;
			}
		}
		else if (rc>0){
			int wt;
			wait(&wt);
			}
		}
	    else if (strcmp(str1[0],"cat")==0){
		int rc=fork();
		if (rc==0){
			if (cnt==2){
				if (execl("./cat",str1[1],NULL)==-1){}
				}
			else if (cnt==3){
				if (execl("./cat",str1[1],str1[2],NULL)==-1){}
				}
			else{
				printf("Invalid arguments");
				break;
			}
		}
		else if (rc>0){
			int wt;
			wait(&wt);
			}
		}
	    else if (strcmp(str1[0],"date")==0){
		int rc=fork();
		if (rc==0){
			if (cnt==1){
				if (execl("./date",NULL)==-1){}
				}
			else if (cnt==2){
				if (execl("./date",str1[1],NULL)==-1){}
				}
			else{
				printf("Invalid arguments");
				break;
			}
		}
		else if (rc>0){
			int wt;
			wait(&wt);
			}
		}
	    else if (strcmp(str1[0],"mkdir")==0){
		int rc=fork();
		if (rc==0){
			if (cnt==2){
				if (execl("./mkdir",str1[1],NULL)==-1){}
				}
			else if (cnt==3){
				if (execl("./mkdir",str1[1],str1[2],NULL)==-1){}
				}
			else{
				printf("Invalid arguments");
				break;
			}
		}
		else if (rc>0){
			int wt;
			wait(&wt);
			}
		}
            }
	printf(">");
    }
    return 0;
}
