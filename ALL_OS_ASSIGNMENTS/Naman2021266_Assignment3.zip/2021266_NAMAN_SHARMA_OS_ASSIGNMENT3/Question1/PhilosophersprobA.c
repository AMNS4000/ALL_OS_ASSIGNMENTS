#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
#include<semaphore.h>
#include<string.h>
typedef struct{
    int id;
    int loopcnt;
}id;
int forks[5];
int getleft(int p){
    return p;
}
int getright(int p){
    return (p+1)%5;
}
void getforktoeat(int pid){
    getleft(pid);
    getright(pid);
    
}
void putforkback(int pid){

}
void think(int pid){
    printf("Philosopher %d has started to think \n", pid);
    sleep(1);
}
void eat(int pid){
    printf("Philosopher %d has started to eat \n ",pid);
    sleep(1);
}
void *philosopher(void *arg){
    id *funcid= (id *)arg;
    int p= funcid->id;
    if (p==1 || p==3){
        sleep(5);
    }
    else if (p==4){
        sleep(6);
    }
    int j;
    think(p);
    getforktoeat(p);
    eat(p);
    putforkback(p);
    return NULL;

}
int main(){
    pthread_t philosopherarr[5];
    for (int j=0; j<5; j++){
        forks[j]=j;
    }
    for (int i=0; i<5; i++){
        id* arg1= malloc(sizeof(id));
        arg1->id=i;
        arg1->loopcnt=5;
        int u= pthread_create(&philosopherarr[i], NULL , philosopher, (void *)arg1);
        if (u){
            printf("Error while creating thread");
        }
    }
    for (int j=0; j<5; j++){
        pthread_join(philosopherarr[j], NULL);
    }
    return 0;
}