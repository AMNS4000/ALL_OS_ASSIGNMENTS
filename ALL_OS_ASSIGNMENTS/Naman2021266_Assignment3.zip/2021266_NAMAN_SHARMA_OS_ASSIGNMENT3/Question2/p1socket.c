#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/un.h>
#define CLIENT_SOCK_FILE "client.sock"
#define SERVER_SOCK_FILE "server.sock"
void stringgenerator(char strarr[100][11]){
    char temp[100]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    for (int g=0; g<50; g++){
        for (int y=0; y<10; y++){
            int randindx= (rand())%62;
            strarr[g][y] = temp[randindx];
            strarr[g][y+1]= '\0';
        
        }
    }
}
int main(){
    char sendarr[100][11];
    stringgenerator(sendarr);
    int sock_fd;
    int receive_fd;
    struct sockaddr_un des;
    char strarr[100];
    int g=1;
    register int sizeofHost;
    
    if ((sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0))<0){
        perror("socket");
        g=0;
    }
    if (g==1){
        memset(&des,0,sizeof(struct sockaddr_un));
        des.sun_family = AF_UNIX;
        strcpy(des.sun_path, CLIENT_SOCK_FILE);
        sizeofHost= sizeof(des.sun_family)+ strlen(des.sun_path);
        if (bind(sock_fd, (struct sockaddr*  )&des, sizeof(des))<0){
            perror("bind");
            g=0;
        }
    }
    if (g==1){
        memset(&des,0,sizeof(struct sockaddr_un));
        des.sun_family = AF_UNIX;
        strcpy(des.sun_path, SERVER_SOCK_FILE);
        sizeofHost= sizeof(des.sun_family)+ strlen(des.sun_path);
        if (connect(sock_fd, (struct sockaddr*  )&des, sizeofHost)==-1){
            perror("connect");
            g=0;
        }
    }
    
    int indx=0;
    for (int h=0; h<10; h++){
        char t[50];
        sprintf(t,"%d",indx);
        strncat(t," ",2);
        for (int o=0; o<5; o++){
            strncat(t,sendarr[indx+o], 10);
            strncat(t," ",2);
        }
        if (g==1){
            strcpy(strarr, t);
            if (send(sock_fd, strarr, strlen(strarr),0)==-1){
                perror("send");
                g=0;
            }
        }
        if (g==1){
            if ((receive_fd = recv(sock_fd, strarr, 100, 0))<0){
                perror("recv");
                g=0;
            }
            sleep(1);
            int id= atoi(strarr);
            printf("ID received is %d\n", id);
        }
        indx+=5;
    }
    if (sock_fd >=0){
        close(sock_fd);
    }
    unlink(CLIENT_SOCK_FILE);
    return 0;
}