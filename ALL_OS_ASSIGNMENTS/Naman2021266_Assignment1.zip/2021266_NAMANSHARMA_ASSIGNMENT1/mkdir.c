#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<dirent.h>
#include<errno.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<string.h>
int main(int argc, char *argv[]){
    if (argc==1){
        DIR* d=opendir(argv[0]); //checking if directory exists already
        if (d){
            printf("mkdir: cannot create directory %s: File exists",argv[0]);
            closedir(d);
            exit(0);
        }
        else{
            if (mkdir(argv[0],0777)==-1){
                perror("Error: ");
                exit(0);
            }
        }
    }
    else if (argc==2 && strcmp(argv[0],"-v")==0){
        DIR* d=opendir(argv[1]); //checking if directory exists already
        if (d){
            printf("mkdir: cannot create directory %s: File exists",argv[1]);
            closedir(d);
            exit(0);
        }
        else{
            if (mkdir(argv[1],0777)==-1){
                perror("Error: ");
                exit(0);
            }
            else{
                printf("mkdir: created directory %s",argv[1]);
            }
        }
    }
    else if (argc==2 && strcmp(argv[0],"-p")==0){
        int i=0;
        int indx=0;
        char *t=strtok(argv[1],"//");
        while (t!=NULL){
            if (mkdir(t,0777)==-1){
                    perror("Error: ");
                    exit(0);
                }
            else{
                chdir(t);
            }
            t=strtok(NULL,"//");
        }
    }
    else{
        perror("Invalid arguments");
        exit(0);
    }

}
