#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/init.h>
#include<linux/kthread.h>
#include<linux/sched.h>
#include<linux/pid.h>
#include<linux/time.h>
#include<linux/moduleparam.h>
#include<linux/stat.h>
#include<linux/cred.h>
#include<asm/uaccess.h>
#include<linux/fs.h>
#include<linux/pid.h>

static int param_var= 0;

module_param(param_var, int , 0644);


static int __init  hello_init(void){
	printk(KERN_ALERT "Displaying the process details read from task struct...");
	struct task_struct *m1;
	struct pid *pid_struct;
	pid_struct = find_get_pid(param_var);
	if (pid_struct == NULL){
		printk( KERN_ERR "Invalid PID\n");
	}
	m1= pid_task(pid_struct, PIDTYPE_PID);
	if (m1== NULL){
		printk( KERN_ERR "Error in getting task_struct\n");
	}
	int pgid= pid_vnr(task_pgrp(m1));
	printk(KERN_INFO "PID is %d\n", m1->pid);
	printk(KERN_INFO "PGID is %d\n", pgid);
	printk(KERN_INFO "UID is %d\n", m1->cred->uid.val);
	printk(KERN_INFO "Command Path for required program is %s\n" , m1->comm);
	
	return 0;
}
static void __exit hello_exit(void){
	printk(KERN_ALERT "Done all the tasks now quitting.. ");
	}
module_init(hello_init);
module_exit(hello_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("NAMAN-2021266");


