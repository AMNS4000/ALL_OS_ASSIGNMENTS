#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>
#include<dirent.h>
void ls(char *d, int a, int r){
    struct dirent *d1;
    DIR *f=opendir(d);
    if (!f){
        if (errno = ENOENT){
            perror("Directory does not exist");
        }
        else{
            perror("Directory is not readable");
        }
        exit(0);
    }
    if (a==0 && r==0){
        while ((d1=readdir(f))!= NULL){
            if (!a && d1->d_name[0]=='.'){
                continue;
            }
            printf("%s ",d1->d_name);
        }
    }
    else if (a==1){
        while ((d1=readdir(f))!= NULL){
            if (!a && d1->d_name[0]=='.'){
                continue;
            }
            printf("%s ",d1->d_name);
        }
    }
    else if (r==1){
        int indx=0;
        char lsl[1000]=" ";
        while ((d1=readdir(f))!= NULL){
            if (!a && d1->d_name[0]=='.'){
                continue;
            }
            int u=0;
            indx++;
            strcat(lsl," ");
            strcat(lsl,d1->d_name);

        }
        int s;
        int e=strlen(lsl)-1;
        for (int g=strlen(lsl)-1; g>=0; g--){
            if (lsl[g]==' ' || g==0){
                if (g==0){
                    s=0;
                }
                else{
                    s=g+1;
                }
                for (int j=s; j<=e; j++){
                    printf("%c",lsl[j]);
                }
                e=g-1;
                printf(" ");
            }
        }
    }
}
int main(int argc, char *argv[]){
    int a=0;
    int r=0;
    if (argc==0){
        ls(".",0,0); //normal ls
    }
    else if (argc==1){ //either ls -a or ls -r
        if (argv[0][0]=='-'){
            if (argv[0][1]=='a' && argv[0][2]=='\0'){
                a=1;
            }
            else if (argv[0][1]=='r' && argv[0][2]=='\0'){
                r=1;
            }
            else{
                perror("Invalid Option no such option is available");
                exit(0);
            }
        }
        ls(".",a,r);
    }
    return 0;
}

