#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
#include<semaphore.h>
#include<string.h>
typedef struct{
    int id;
    int loopcnt;
}id;
int forks[5];
int saucebowl[2];
int getleft(int p){
    return p;
}
int getright(int p){
    return (p+1)%5;
}
int getsaucebowl(int p){
    return (p%2);
}
void getforktoeat(int pid){
    getleft(pid);
    getright(pid);
    
}
void getbowl(int pid){
    getsaucebowl(pid);
    printf("Bowl given to philosopher %d ", pid);
    sleep(1);
    return ;
}
void putforkback(int pid){
    return;
}
void putbowlback(int pid){
    return;
}
void think(int pid){
    printf("Philosopher %d has started to think \n", pid);
}
void eat(int pid){
    printf("Philosopher %d has started to eat \n ",pid);
}
void *philosopher(void *arg){
    id *funcid= (id *)arg;
    int p= funcid->id;
    if (p==1 || p==3){
        sleep(6);
    }
    else if (p==4){
        sleep(7);
    }
    int j;
    think(p);
    getforktoeat(p);
    getbowl(p);
    eat(p);
    putbowlback(p);
    putforkback(p);
    return NULL;

}
int main(){
    pthread_t philosopherarr[5];
    for (int j=0; j<5; j++){
        forks[j]=j;
    }
    saucebowl[0]=0;
    saucebowl[1]=1;
    for (int i=0; i<5; i++){
        id* arg1= malloc(sizeof(id));
        arg1->id=i;
        arg1->loopcnt=5;
        int u= pthread_create(&philosopherarr[i], NULL , philosopher, (void *)arg1);
        if (u){
            printf("Error while creating thread");
        }
    }
    for (int j=0; j<5; j++){
        pthread_join(philosopherarr[j], NULL);
    }
    return 0;
}