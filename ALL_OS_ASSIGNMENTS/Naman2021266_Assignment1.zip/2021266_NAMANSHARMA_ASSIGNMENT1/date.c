#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<errno.h>
#include<string.h>
int main(int argc, char *argv[]){
    time_t t;
    struct tm* utime;
    time(&t);
    utime=gmtime(&t);
    if (argc==1 && strcmp(argv[0],"-u")!=0 && strcmp(argv[0],"-R")!=0){
        switch(utime->tm_wday){
            case 0:
                printf("Sun");
                break;
            case 1:
                printf("Mon");
                break;
            case 2:
                printf("Tue");
                break;
            case 3:
                printf("Wed");
                break;
            case 4:
                printf("Thu");
                break;
            case 5:
                printf("Fri");
                break;
            case 6:
                printf("Sat");
                break;
        }
        printf(" ");
        switch(utime->tm_mon){
            case 0:
                printf("Jan");
                break;
            case 1:
                printf("Feb");
                break;
            case 2:
                printf("Mar");
                break;
            case 3:
                printf("Apr");
                break;
            case 4:
                printf("May");
                break;
            case 5:
                printf("Jun");
                break;
            case 6:
                printf("Jul");
                break;
            case 7:
                printf("Aug");
                break;
            case 8:
                printf("Sep");
                break;
            case 9:
                printf("Oct");
                break;
            case 10:
                printf("Nov");
                break;
            case 11:
                printf("Dec");
                break;
        }
        printf(" ");
        int g=utime->tm_mday;
        printf("%d ",g);
        utime->tm_hour+=5;
        utime->tm_min+=30;
        if (utime->tm_hour>12){
            printf("%d:%d:%d",utime->tm_hour-12,utime->tm_min,utime->tm_sec);
            printf(" PM ");
            printf("IST");
            printf("%d",1900+utime->tm_year);
        }
        else{
            printf("%d:%d:%d",utime->tm_hour,utime->tm_min,utime->tm_sec);
            printf(" AM ");
            printf("IST ");
            printf("%d",1900+utime->tm_year);
        }
    }
    else if (argc==1 && strcmp(argv[0],"-u")==0){
        switch(utime->tm_wday){
            case 0:
                printf("Sun");
                break;
            case 1:
                printf("Mon");
                break;
            case 2:
                printf("Tue");
                break;
            case 3:
                printf("Wed");
                break;
            case 4:
                printf("Thu");
                break;
            case 5:
                printf("Fri");
                break;
            case 6:
                printf("Sat");
                break;
        }
        printf(" ");
        switch(utime->tm_mon){
            case 0:
                printf("Jan");
                break;
            case 1:
                printf("Feb");
                break;
            case 2:
                printf("Mar");
                break;
            case 3:
                printf("Apr");
                break;
            case 4:
                printf("May");
                break;
            case 5:
                printf("Jun");
                break;
            case 6:
                printf("Jul");
                break;
            case 7:
                printf("Aug");
                break;
            case 8:
                printf("Sep");
                break;
            case 9:
                printf("Oct");
                break;
            case 10:
                printf("Nov");
                break;
            case 11:
                printf("Dec");
                break;
        }
        printf(" ");
        int g=utime->tm_mday;
        printf("%d ",g);
        if (utime->tm_hour>12){
            printf("%d:%d:%d",utime->tm_hour-12,utime->tm_min,utime->tm_sec);
            printf(" PM ");
            printf("UTC");
            printf("%d",1900+utime->tm_year);
        }
        else{
            printf("%d:%d:%d",utime->tm_hour,utime->tm_min,utime->tm_sec);
            printf(" AM ");
            printf("UTC ");
            printf("%d",1900+utime->tm_year);
        }
    }
    else if (argc==1 && strcmp(argv[0],"-R")==0){
        switch(utime->tm_wday){
            case 0:
                printf("Sun,");
                break;
            case 1:
                printf("Mon,");
                break;
            case 2:
                printf("Tue,");
                break;
            case 3:
                printf("Wed,");
                break;
            case 4:
                printf("Thu,");
                break;
            case 5:
                printf("Fri,");
                break;
            case 6:
                printf("Sat,");
                break;
        }
        printf(" ");
        int g=utime->tm_mday;
        printf("%d ",g);
        switch(utime->tm_mon){
            case 0:
                printf("Jan");
                break;
            case 1:
                printf("Feb");
                break;
            case 2:
                printf("Mar");
                break;
            case 3:
                printf("Apr");
                break;
            case 4:
                printf("May");
                break;
            case 5:
                printf("Jun");
                break;
            case 6:
                printf("Jul");
                break;
            case 7:
                printf("Aug");
                break;
            case 8:
                printf("Sep");
                break;
            case 9:
                printf("Oct");
                break;
            case 10:
                printf("Nov");
                break;
            case 11:
                printf("Dec");
                break;
        }
        printf(" "); 
        printf("%d ",1900+utime->tm_year);
        printf("%d:%d:%d",utime->tm_hour+5,utime->tm_min+30,utime->tm_sec);
        printf(" +0530 ");
    }
    else{
        perror("Invalid argument passed.");
        exit(0);
    }
    
    
}
