#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<sys/mman.h>
#include<sys/un.h>
#include<sys/stat.h>
#include<string.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
#define SHM_PATH "address"
#define SIZE 512
void stringgenerator(char strarr[50][10]){
    char temp[100]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    for (int g=0; g<50; g++){
        for (int y=0; y<10; y++){
            int randindx= (rand())%62;
            strarr[g][y] = temp[randindx];
            strarr[g][y+1]= '\0';
        
        }
    }
}
int main() { 
    char toSend[15];
    char sendarr[50][10];
    stringgenerator(sendarr);
    int indx= 0;
    char indxarr[10];
    int shm;
    if ((shm = shm_open(SHM_PATH, O_CREAT | O_RDWR, 666)) < 0) {
        printf("Error in opening");
        return 0;
    }

    if (ftruncate(shm, SIZE) < 0) {
        printf("Shared memory not truncated ");
        return 0;
    }
    indx=0;
    char* region = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm, 0);
    while (1) {
        for (int i=indx; i<indx+5; indx++) {

        
            char num[5];
            sprintf(num, "%d", i);
            char temp[12];
            sprintf(temp,"%s",sendarr[i]);
            strcat(temp, num);
            strcat(temp, "\0");
            sprintf(region, "%s", temp);
            region += strlen(temp) + 1;
        }

        char maxarr[5];
        sprintf(maxarr,"%d",indx+4);

        while (strcmp(region,maxarr)) {
            continue;
        }
        char* maxIndStr = (char*) region;
        region += strlen(maxIndStr) + 1;
        int retindx = atoi(maxIndStr);
        printf("[SERVER] Maximum index received: %d\n", retindx);

        if (retindx == 49) {
        break;
        }

        indx += 5;
    }

    munmap(region, SIZE);
    close(shm);
    shm_unlink(SHM_PATH);
  return 0;
}