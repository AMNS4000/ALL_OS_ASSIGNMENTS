#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<dirent.h>
#include<string.h>
#include<errno.h>
int main(int argc, char *argv[]){
    FILE *file;
    FILE *f;
    char catl[100];
    file=fopen(argv[0],"r");
    if (!file){
        perror("Error file doesnt exist");
        exit(0);
    }
    else if (argc==1){
        char ch;
        while ((ch=fgetc(file))!=EOF){
            printf("%c",ch);
        }
    }
    else if (argc==2 && strcmp(argv[1],"-n")==0){ // for cat t1.txt -n 
        int i=1;
        while (fscanf(file,"%[^\n] ",catl)!=EOF){
            printf("%d) %s\n",i,catl);
            i++;
        }
    }
    else if (argc==2 && strcmp(argv[1],"-E")==0){
        while (fscanf(file,"%[^\n] ",catl)!=EOF){
            printf("%s$\n",catl);
        }
    }
    else if (argc>=3){
        perror("Wrong arguments passed");
        exit(0);
    }
    fclose(file);
    return 0;
}
