#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>
#include<sys/types.h>
int main(){
    int fd;
    for (int g=0; g<10; g++){
        char receivearr[100];
        char indxarr[100];
        fd = open("pipeOS", O_RDONLY);
        sleep(1);
        int res=read(fd, receivearr, sizeof(receivearr));
        if (res==-1){
            printf("Error reading");
        }
        close(fd);
        strncpy(indxarr, receivearr, 2);
        int indx= atoi(indxarr);
        int add;   //we need to read after we read the id of 2 places
        if (indx>=10){
            add=3;
        }
        else if (0<=indx<10){
            add=2;
        }
        char a1[15];
        for (int i=0; i<10; i++){
            a1[i]= receivearr[add+i];
        }
        char a2[15];
        for (int i=0; i<10; i++){
            a2[i]= receivearr[add+i+11];
        }
        char a3[15];
        for (int i=0; i<10; i++){
            a3[i]= receivearr[add+i+22];
        }
        char a4[15];
        for (int i=0; i<10; i++){
            a4[i]= receivearr[add+i+33];
        }
        char a5[15];
        for (int i=0; i<10; i++){
            a5[i]= receivearr[add+i+44];
        }
        int o=1;
        printf("String 1: %d with Index: %s\n",indx, a1);
        printf("String 2: %d with Index: %s\n",indx+1, a2);
        printf("String 3: %d with Index: %s\n",indx+2, a3);
        printf("String 4: %d with Index: %s\n",indx+3, a4);
        printf("String 5: %d with Index: %s\n",indx+4, a5);
        printf("\n");
        int fd1;
        fd1=open("pipeOS", O_WRONLY);
        int retid= indx+4;
        char t1[5];
        sprintf(t1, "%d", retid);
        int re=write(fd1, t1, sizeof(t1));
        if (re==-1){
            printf("Error while writing");
        }
        close(fd1);
    }
    return 0;
}