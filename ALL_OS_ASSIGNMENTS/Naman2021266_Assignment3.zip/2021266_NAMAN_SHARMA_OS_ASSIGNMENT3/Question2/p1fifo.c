#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>
#include<sys/types.h>
void stringgenerator(char strarr[50][10]){
    char temp[100]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    for (int g=0; g<50; g++){
        for (int y=0; y<10; y++){
            int randindx= (rand())%62;
            strarr[g][y] = temp[randindx];
            strarr[g][y+1]= '\0';
        
        }
    }
}
int main(){
    char arraystring[50][10];
    stringgenerator(arraystring);
    int fd;
    mkfifo("pipeOS", 0666);
    int cnt=0;
    int id=0;
    int iter=0;
    while (id<50){
        
        if (iter!=0){
            int fd1;
            fd1=open("pipeOS",O_RDONLY);
            sleep(1);
            char receivearr[100];
            int y=read(fd1, receivearr, sizeof(receivearr));
            if (y==-1){
                printf("Error in reading");
            }
            close(fd1);
            receivearr[99]=0;  //else error as '\0' is not integer 
            id= atoi(receivearr);
            printf("ID received from P2 is : %d\n", id);
            id++;

        }
        if (id<50){
            iter=1;
            char sendarr[100]="";
            int fd=open("pipeOS",O_WRONLY);
            if (fd==-1){
                printf("Error opening");
            }
            sprintf(sendarr, "%d", id);
            strncat(sendarr, " ", 2);
            for (int g=0; g<5; g++){
                strncat(sendarr, arraystring[id+g], 10);
                strncat(sendarr, " ", 2);
            }
            int res=write(fd, sendarr, sizeof(sendarr));
            if (res==-1){
                printf("Error writing");
            }
            close(fd);
        }
        
    }
    return 0;
}
