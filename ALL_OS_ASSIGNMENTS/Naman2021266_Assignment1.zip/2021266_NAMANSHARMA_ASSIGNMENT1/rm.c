#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<dirent.h>
#include<errno.h>
int main(int argc, char *argv[]){
    if (argc==1){
        DIR* d=opendir(argv[0]); //checking whether is file is not a directory
        if (d){
            printf("rm: cannot remove %s: Is a directory");
            closedir(d);
            exit(0);
        }
        else{
            if (remove(argv[0])==0){
                exit(1);
            }
            else{
                perror("Unable to delete the file");
                exit(0);
            }
        }
    }
    else if (argc==2){ // for interactive deletion
        if (strcmp(argv[1],"-i")==0){
            DIR* d=opendir(argv[0]); //checking whether is file is not a directory
            if (d){
                printf("rm: cannot remove %s: Is a directory",argv[0]);
                closedir(d);
                exit(0);
            }
            else{
                printf("rm : remove regular empty file %s",argv[0]);
                char t;
                scanf("%c",&t);
                if (t=='y'){
                    if (remove(argv[0])==0){
                        exit(1);
                    }
                    else{
                        perror("Unable to delete the file");
                        exit(0);
                    }
                }
                else{
                    exit(1);
                }
                
            }
            
        }
        else if (strcmp(argv[1],"-v")==0){
            DIR* d=opendir(argv[0]); //checking whether is file is not a directory
            if (d){
                printf("rm: cannot remove %s: Is a directory");
                closedir(d);
                exit(0);
            }
            else{
                if (remove(argv[0])==0){
                    printf("removed %s",argv[0]);
                    exit(1);
                }
                else{
                    perror("Unable to delete the file");
                    exit(0);
                }
            }
        }
    }
    else{
        perror("Invalid arguments.");
        exit(0);
    }

}
