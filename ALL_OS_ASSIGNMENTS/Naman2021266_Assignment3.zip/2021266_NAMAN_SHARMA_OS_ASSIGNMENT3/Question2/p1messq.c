#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<fcntl.h>
#include<sys/wait.h>
#include<sys/stat.h>
#include<sys/msg.h>
#include<sys/ipc.h>
#define PROJECT_PATHNAME "p1messq.c"
#define PROJECT_ID 57
#define MSG_SIZE 512

struct mqdq{
    long x;
    int indx1;
    int indx2;
    int indx3;
    int indx4;
    int indx5;
    char str1[100];
    char str2[100];
    char str3[100];
    char str4[100];
    char str5[100];
}myqd;
struct retmsg{
    long x1;
    int indxret;
}retvalue;
void stringgenerator(char strarr[100][11]){
    char temp[100]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    for (int g=0; g<50; g++){
        for (int y=0; y<10; y++){
            int randindx= (rand())%62;
            strarr[g][y] = temp[randindx];
            strarr[g][y+1]= '\0';
        
        }
    }
}
int main(int argc, char *argv[]){
    char sendarr[100][11];
    stringgenerator(sendarr);
    key_t messkey= ftok(PROJECT_PATHNAME,PROJECT_ID);
    if (messkey==-1){
        printf("Message key is not generated");
    }
    int id= msgget(messkey, 0666|IPC_CREAT);
    if (id==-1){
        printf("Error in getting queue initialized");
    }
    int indx=0;
    for (int i=0; i<10; i++){
        myqd.indx1=indx;
        strcpy(myqd.str1, sendarr[indx]);
        myqd.indx2=indx+1;
        strcpy(myqd.str2, sendarr[indx+1]);
        myqd.indx3=indx+2;
        strcpy(myqd.str3, sendarr[indx+2]);
        myqd.indx4=indx+3;
        strcpy(myqd.str4, sendarr[indx+3]);
        myqd.indx5=indx+4;
        strcpy(myqd.str5, sendarr[indx+4]);
        myqd.x=12345;
        if (msgsnd(id,&myqd,MSG_SIZE,0)==-1){
            printf("Error in sending the message\n");
            return -1;
        }
        indx+=5;
        sleep(1);
        printf("Receiving Highest ID from P2 \n");
        if (msgrcv(id,&retvalue,MSG_SIZE,54321,0)==-1){
            printf("Error in receiving from P2");
            return -1;
        }
        printf("ID received is %d\n",retvalue.indxret);
    }
}