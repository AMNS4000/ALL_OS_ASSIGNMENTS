#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/un.h>
#define CLIENT_SOCK_FILE "client.sock"
#define SERVER_SOCK_FILE "server.sock"
int main(){
    int sock_fd;
    int send_fd;
    int receive_fd;
    struct sockaddr_un des;
    struct sockaddr_un src;
    char recarr[100];
    int g=1;
    socklen_t addr= sizeof(src);
    if ((sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0))<0){
        perror("socket");
        g=0;
    }
    if (g==1){
        memset(&des, 0, sizeof(des));
        des.sun_family= AF_UNIX;
        strcpy(des.sun_path, SERVER_SOCK_FILE);
        unlink(SERVER_SOCK_FILE);
        if (bind(sock_fd, (struct sockaddr *)&des, sizeof(des))<0){
            perror("bind");
            g=0;
        }
    }
    while ((receive_fd = recvfrom(sock_fd, recarr, 100, 0, (struct sockaddr*)&src, &addr))>0){
        char t[50];
        strncpy(t, recarr, 2);
        int id= atoi(t);
        int add;
        if (id>=10){
            add=3;
        }
        else if (0<=id<10){
            add=2;
        }
        char a1[15];
        for (int i=0; i<10; i++){
            a1[i]= recarr[add+i];
        }
        char a2[15];
        for (int i=0; i<10; i++){
            a2[i]= recarr[add+i+11];
        }
        char a3[15];
        for (int i=0; i<10; i++){
            a3[i]= recarr[add+i+22];
        }
        char a4[15];
        for (int i=0; i<10; i++){
            a4[i]= recarr[add+i+33];
        }
        char a5[15];
        for (int i=0; i<10; i++){
            a5[i]= recarr[add+i+44];
        }
        sleep(1);
        printf("Index of String: %d String is %s\n", id, a1);
        printf("Index of String: %d String is %s\n", id+1, a2);
        printf("Index of String: %d String is %s\n", id+2, a3);
        printf("Index of String: %d String is %s\n", id+3, a4);
        printf("Index of String: %d String is %s\n", id+4, a5);
        int retvalue= id+4;
        char t2[5];
        sprintf(t2, "%d", retvalue);
        send_fd= sendto(sock_fd, t2, strlen(t2), 0, (struct sockaddr *)&src, addr);
        if (send_fd < 0){
            perror("sendto");
            break;
        }
    }
    if (sock_fd >=0 ){
        close(sock_fd);
        exit(EXIT_SUCCESS);
    }
    unlink(SERVER_SOCK_FILE);
    return 0;
}